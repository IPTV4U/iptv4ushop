<?php

/*
 * ==========================================================
 * INITIAL CONFIGURATION FILE
 * ==========================================================
 *
 * Insert here the information for the database connection and for other core settings.
 *
 */

/* Plugin folder url */
define('SB_URL', 'https://rafs.xyz/wp/saas_new/wp-content/plugins/supportboard/supportboard');

/* The name of the database */
define('SB_DB_NAME', 'smuvmjni_wp13');

/* MySQL database username */
define('SB_DB_USER', 'smuvmjni_wp13');

/* MySQL database password */
define('SB_DB_PASSWORD', '1@7r7Sp-08');

/* MySQL hostname */
define('SB_DB_HOST', 'localhost');

/* MySQL port (optional) */
define('SB_DB_PORT', '');

/* WordPress prefix */
define('SB_WP_PREFIX', 'wp7d_');

/* Upload path */
define('SB_UPLOAD_PATH', '/home/smuvmjni/public_html/wp/saas_new/wp-content/uploads/sb');

/* Upload url */
define('SB_UPLOAD_URL', 'https://rafs.xyz/wp/saas_new/wp-content/uploads/sb');

?>